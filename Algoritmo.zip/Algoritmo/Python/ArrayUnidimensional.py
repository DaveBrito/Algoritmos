
vetor = []
for c in range(5):
    vetor.append(int(input('Digite algum valor: ' )))
print (vetor)    
print ('Maior número da lista: ', max(vetor))
print ('Menor número da lista: ', min(vetor))
print ('Soma de todos os valores: ', sum(vetor))

